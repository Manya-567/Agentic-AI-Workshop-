def evaluate_participation(user_input, full_transcript):
    user_lines = user_input.strip().split(".")
    clarity_score = sum(1 for line in user_lines if len(line.split()) > 5) / len(user_lines)

    talk_time_pct = len(user_input.split()) / len(full_transcript.split()) * 100
    counterarguments_missed = "Yes" if "however" not in user_input.lower() else "No"
    needs_structure = "Yes" if clarity_score < 0.6 else "No"

    return {
        "Talk Time %": f"{talk_time_pct:.1f}%",
        "Clarity Score": round(clarity_score, 2),
        "Missed Counterarguments": counterarguments_missed,
        "Needs Better Structure": needs_structure
    }