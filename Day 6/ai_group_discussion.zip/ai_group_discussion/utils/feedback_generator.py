def generate_feedback_report(evaluation):
    suggestions = []
    if float(evaluation["Talk Time %"].strip('%')) < 30:
        suggestions.append("- Participate more actively.")
    if evaluation["Missed Counterarguments"] == "Yes":
        suggestions.append("- Include counterarguments like 'however', 'on the other hand'.")
    if evaluation["Needs Better Structure"] == "Yes":
        suggestions.append("- Structure your thoughts using clear points and transitions.")

    best_practices = """
- Speak in clear, complete ideas.
- Respect time and avoid interruptions.
- Address other viewpoints constructively.
- Keep your arguments structured and concise.
"""

    return "\n".join(suggestions) + "\n\n**Best Practices:**\n" + best_practices