import streamlit as st
from agents.participant_agent import simulate_group_discussion
from agents.evaluator_agent import evaluate_participation
from utils.feedback_generator import generate_feedback_report

st.set_page_config(page_title="AI Group Discussion Synthesizer", layout="wide")

st.title("🧠 AI Group Discussion Synthesizer")
st.write("Simulate, participate, and get your performance report!")

user_input = st.text_area("💬 Enter your participation content or argument:", height=200)

if st.button("Start AI Discussion"):
    with st.spinner("Simulating AI group members..."):
        discussion_transcript = simulate_group_discussion(user_input)

    st.subheader("🧾 Simulated Discussion Transcript")
    st.code(discussion_transcript)

    with st.spinner("Evaluating your participation..."):
        evaluation = evaluate_participation(user_input, discussion_transcript)
        feedback = generate_feedback_report(evaluation)

    st.subheader("📊 Your Evaluation Report")
    st.json(evaluation)

    st.subheader("💡 Suggestions to Improve")
    st.write(feedback)